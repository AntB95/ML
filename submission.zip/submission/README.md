# EPFL Machine Learning Project 1 README

This submission�� folder contains the following 9 elements:

- proj1_helpers.py: Contains the helper functions provided for the project1.

- implementations.py: Contains the implementation of the prediction functions, least_squares, least_squares_GD, least_squares_SGD, ridge_regression, logistic_regression, reg_logistic_regression and additional function in order to compute the prediction functions. 

- run.py: The script that generate the file final_prediction.csv 

- annexe.py: Contains all other help function needed in the project, such as sigmoid, build_poly, standardize, add_function and so on. 

- Cross_validation.ipynb: The Jupiter Notebook we use to do our cross validation and explore the dataset. You need the packages pandas, numpy and seaborn to run this code

- final_prediction.csv: This .csv file contains the predictions obtained by running the run.py script. This is the prediction file that has been submitted to AICrowd and gave the final score.

- Data Folder: Where you should put the train set and the test set, as .csv files.

- Figures Folder: Contains the 5 images used in the report and generate by Cross_validation.ipynb
